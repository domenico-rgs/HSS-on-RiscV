#include "functions.h"
#include "segmenter.h"
#include <stdio.h>
#include <time.h>
#include <string.h>

int main(){
    FILE* weights = fopen("weigths.txt", "r");
    FILE* input = fopen("input.txt", "r");
    FILE* output = fopen("output_C.txt", "w");

    float *x = (float *)malloc(sizeof(float) * N * N_FEATURES);
    float *enc_0_conv_relu_0_w = (float *)malloc(sizeof(float) * ENC_0_CONV_RELU_0_K * ENC_0_CONV_RELU_0_INPUT_FEATURES*ENC_0_CONV_RELU_0_OUTPUT_FEATURES);
    float *enc_0_conv_relu_1_w = (float *)malloc(sizeof(float) * ENC_0_CONV_RELU_1_K * ENC_0_CONV_RELU_1_INPUT_FEATURES*ENC_0_CONV_RELU_1_OUTPUT_FEATURES);
    float *enc_1_conv_relu_0_w = (float *)malloc(sizeof(float) *ENC_1_CONV_RELU_0_K*ENC_1_CONV_RELU_0_INPUT_FEATURES*ENC_1_CONV_RELU_0_OUTPUT_FEATURES);
    float *enc_1_conv_relu_1_w = (float *)malloc(sizeof(float) *ENC_1_CONV_RELU_1_K*ENC_1_CONV_RELU_1_INPUT_FEATURES*ENC_1_CONV_RELU_1_OUTPUT_FEATURES);
    float *enc_2_conv_relu_0_w = (float *)malloc(sizeof(float) *ENC_2_CONV_RELU_0_K*ENC_2_CONV_RELU_0_INPUT_FEATURES*ENC_2_CONV_RELU_0_OUTPUT_FEATURES);
    float *enc_2_conv_relu_1_w = (float *)malloc(sizeof(float) *ENC_2_CONV_RELU_1_K*ENC_2_CONV_RELU_1_INPUT_FEATURES*ENC_2_CONV_RELU_1_OUTPUT_FEATURES);
    float *enc_3_conv_relu_0_w = (float *)malloc(sizeof(float) *ENC_3_CONV_RELU_0_K*ENC_3_CONV_RELU_0_INPUT_FEATURES*ENC_3_CONV_RELU_0_OUTPUT_FEATURES);
    float *enc_3_conv_relu_1_w = (float *)malloc(sizeof(float) *ENC_3_CONV_RELU_1_K*ENC_3_CONV_RELU_1_INPUT_FEATURES*ENC_3_CONV_RELU_1_OUTPUT_FEATURES);
    float *central_conv_relu_0_w = (float *)malloc(sizeof(float) *CENTRAL_CONV_RELU_0_K*CENTRAL_CONV_RELU_0_INPUT_FEATURES*CENTRAL_CONV_RELU_0_OUTPUT_FEATURES);
    float *central_conv_relu_1_w = (float *)malloc(sizeof(float) *CENTRAL_CONV_RELU_1_K*CENTRAL_CONV_RELU_1_INPUT_FEATURES*CENTRAL_CONV_RELU_1_OUTPUT_FEATURES);
    float *dec_0_up_conv_relu_w = (float *)malloc(sizeof(float) *DEC_0_UP_CONV_RELU_K*DEC_0_UP_CONV_RELU_INPUT_FEATURES*DEC_0_UP_CONV_RELU_OUTPUT_FEATURES);
    float *dec_0_conv_relu_0_w = (float *)malloc(sizeof(float) *DEC_0_CONV_RELU_0_K*DEC_0_CONV_RELU_0_INPUT_FEATURES*DEC_0_CONV_RELU_0_OUTPUT_FEATURES);
    float *dec_0_conv_relu_1_w = (float *)malloc(sizeof(float) *DEC_0_CONV_RELU_1_K*DEC_0_CONV_RELU_1_INPUT_FEATURES*DEC_0_CONV_RELU_1_OUTPUT_FEATURES);
    float *dec_1_up_conv_relu_w = (float *)malloc(sizeof(float) *DEC_1_UP_CONV_RELU_K*DEC_1_UP_CONV_RELU_INPUT_FEATURES*DEC_1_UP_CONV_RELU_OUTPUT_FEATURES);
    float *dec_1_conv_relu_0_w = (float *)malloc(sizeof(float) *DEC_1_CONV_RELU_0_K*DEC_1_CONV_RELU_0_INPUT_FEATURES*DEC_1_CONV_RELU_0_OUTPUT_FEATURES);
    float *dec_1_conv_relu_1_w = (float *)malloc(sizeof(float) *DEC_1_CONV_RELU_1_K*DEC_1_CONV_RELU_1_INPUT_FEATURES*DEC_1_CONV_RELU_1_OUTPUT_FEATURES);
    float *dec_2_up_conv_relu_w = (float *)malloc(sizeof(float) *DEC_2_UP_CONV_RELU_K*DEC_2_UP_CONV_RELU_INPUT_FEATURES*DEC_2_UP_CONV_RELU_OUTPUT_FEATURES);
    float *dec_2_conv_relu_0_w = (float *)malloc(sizeof(float) *DEC_2_CONV_RELU_0_K*DEC_2_CONV_RELU_0_INPUT_FEATURES*DEC_2_CONV_RELU_0_OUTPUT_FEATURES);
    float *dec_2_conv_relu_1_w = (float *)malloc(sizeof(float) *DEC_2_CONV_RELU_1_K*DEC_2_CONV_RELU_1_INPUT_FEATURES*DEC_2_CONV_RELU_1_OUTPUT_FEATURES);
    float *dec_3_up_conv_relu_w = (float *)malloc(sizeof(float) *DEC_3_UP_CONV_RELU_K*DEC_3_UP_CONV_RELU_INPUT_FEATURES*DEC_3_UP_CONV_RELU_OUTPUT_FEATURES);
    float *dec_3_conv_relu_0_w = (float *)malloc(sizeof(float) *DEC_3_CONV_RELU_0_K*DEC_3_CONV_RELU_0_INPUT_FEATURES*DEC_3_CONV_RELU_0_OUTPUT_FEATURES);
    float *dec_3_conv_relu_1_w = (float *)malloc(sizeof(float) *DEC_3_CONV_RELU_1_K*DEC_3_CONV_RELU_1_INPUT_FEATURES*DEC_3_CONV_RELU_1_OUTPUT_FEATURES);
    float *final_conv_w = (float *)malloc(sizeof(float) *FINAL_CONV_K*FINAL_CONV_INPUT_FEATURES*FINAL_CONV_OUTPUT_FEATURES);
    float *y = (float *)malloc(sizeof(float) *N*N_STATES);

    memset(x,0,sizeof(float) * N * N_FEATURES);
    memset(enc_0_conv_relu_0_w,0,sizeof(float) * ENC_0_CONV_RELU_0_K * ENC_0_CONV_RELU_0_INPUT_FEATURES*ENC_0_CONV_RELU_0_OUTPUT_FEATURES);
    memset(enc_0_conv_relu_1_w ,0,sizeof(float) * ENC_0_CONV_RELU_1_K * ENC_0_CONV_RELU_1_INPUT_FEATURES*ENC_0_CONV_RELU_1_OUTPUT_FEATURES);
    memset(enc_1_conv_relu_0_w ,0,sizeof(float) *ENC_1_CONV_RELU_0_K*ENC_1_CONV_RELU_0_INPUT_FEATURES*ENC_1_CONV_RELU_0_OUTPUT_FEATURES);
    memset(enc_1_conv_relu_1_w ,0,sizeof(float) *ENC_1_CONV_RELU_1_K*ENC_1_CONV_RELU_1_INPUT_FEATURES*ENC_1_CONV_RELU_1_OUTPUT_FEATURES);
    memset(enc_2_conv_relu_0_w ,0,sizeof(float) *ENC_2_CONV_RELU_0_K*ENC_2_CONV_RELU_0_INPUT_FEATURES*ENC_2_CONV_RELU_0_OUTPUT_FEATURES);
    memset(enc_2_conv_relu_1_w ,0,sizeof(float) *ENC_2_CONV_RELU_1_K*ENC_2_CONV_RELU_1_INPUT_FEATURES*ENC_2_CONV_RELU_1_OUTPUT_FEATURES);
    memset(enc_3_conv_relu_0_w ,0,sizeof(float) *ENC_3_CONV_RELU_0_K*ENC_3_CONV_RELU_0_INPUT_FEATURES*ENC_3_CONV_RELU_0_OUTPUT_FEATURES);
    memset(enc_3_conv_relu_1_w ,0,sizeof(float) *ENC_3_CONV_RELU_1_K*ENC_3_CONV_RELU_1_INPUT_FEATURES*ENC_3_CONV_RELU_1_OUTPUT_FEATURES);
    memset(central_conv_relu_0_w ,0,sizeof(float) *CENTRAL_CONV_RELU_0_K*CENTRAL_CONV_RELU_0_INPUT_FEATURES*CENTRAL_CONV_RELU_0_OUTPUT_FEATURES);
    memset(central_conv_relu_1_w ,0,sizeof(float) *CENTRAL_CONV_RELU_1_K*CENTRAL_CONV_RELU_1_INPUT_FEATURES*CENTRAL_CONV_RELU_1_OUTPUT_FEATURES);
    memset(dec_0_up_conv_relu_w,0,sizeof(float) *DEC_0_UP_CONV_RELU_K*DEC_0_UP_CONV_RELU_INPUT_FEATURES*DEC_0_UP_CONV_RELU_OUTPUT_FEATURES);
    memset(dec_0_conv_relu_0_w ,0,sizeof(float) *DEC_0_CONV_RELU_0_K*DEC_0_CONV_RELU_0_INPUT_FEATURES*DEC_0_CONV_RELU_0_OUTPUT_FEATURES);
    memset(dec_0_conv_relu_1_w ,0,sizeof(float) *DEC_0_CONV_RELU_1_K*DEC_0_CONV_RELU_1_INPUT_FEATURES*DEC_0_CONV_RELU_1_OUTPUT_FEATURES);
    memset(dec_1_up_conv_relu_w ,0,sizeof(float) *DEC_1_UP_CONV_RELU_K*DEC_1_UP_CONV_RELU_INPUT_FEATURES*DEC_1_UP_CONV_RELU_OUTPUT_FEATURES);
    memset(dec_1_conv_relu_0_w ,0,sizeof(float) *DEC_1_CONV_RELU_0_K*DEC_1_CONV_RELU_0_INPUT_FEATURES*DEC_1_CONV_RELU_0_OUTPUT_FEATURES);
    memset(dec_1_conv_relu_1_w ,0,sizeof(float) *DEC_1_CONV_RELU_1_K*DEC_1_CONV_RELU_1_INPUT_FEATURES*DEC_1_CONV_RELU_1_OUTPUT_FEATURES);
    memset(dec_2_up_conv_relu_w ,0,sizeof(float) *DEC_2_UP_CONV_RELU_K*DEC_2_UP_CONV_RELU_INPUT_FEATURES*DEC_2_UP_CONV_RELU_OUTPUT_FEATURES);
    memset(dec_2_conv_relu_0_w ,0,sizeof(float) *DEC_2_CONV_RELU_0_K*DEC_2_CONV_RELU_0_INPUT_FEATURES*DEC_2_CONV_RELU_0_OUTPUT_FEATURES);
    memset(dec_2_conv_relu_1_w ,0,sizeof(float) *DEC_2_CONV_RELU_1_K*DEC_2_CONV_RELU_1_INPUT_FEATURES*DEC_2_CONV_RELU_1_OUTPUT_FEATURES);
    memset(dec_3_up_conv_relu_w ,0,sizeof(float) *DEC_3_UP_CONV_RELU_K*DEC_3_UP_CONV_RELU_INPUT_FEATURES*DEC_3_UP_CONV_RELU_OUTPUT_FEATURES);
    memset(dec_3_conv_relu_0_w ,0,sizeof(float) *DEC_3_CONV_RELU_0_K*DEC_3_CONV_RELU_0_INPUT_FEATURES*DEC_3_CONV_RELU_0_OUTPUT_FEATURES);
    memset(dec_3_conv_relu_1_w ,0,sizeof(float) *DEC_3_CONV_RELU_1_K*DEC_3_CONV_RELU_1_INPUT_FEATURES*DEC_3_CONV_RELU_1_OUTPUT_FEATURES);
    memset(final_conv_w ,0,sizeof(float) *FINAL_CONV_K*FINAL_CONV_INPUT_FEATURES*FINAL_CONV_OUTPUT_FEATURES);
    memset(y ,0,sizeof(float) *N*N_STATES);
    

    //load weigths and input data
    for (int j = 0; j < ENC_0_CONV_RELU_0_K*ENC_0_CONV_RELU_0_INPUT_FEATURES*ENC_0_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &enc_0_conv_relu_0_w[j]);
    }
    for (int j = 0; j < ENC_0_CONV_RELU_1_K*ENC_0_CONV_RELU_1_INPUT_FEATURES*ENC_0_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &enc_0_conv_relu_1_w[j]);
    }
    for (int j = 0; j < ENC_1_CONV_RELU_0_K*ENC_1_CONV_RELU_0_INPUT_FEATURES*ENC_1_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &enc_1_conv_relu_0_w[j]);
    }
    for (int j = 0; j < ENC_1_CONV_RELU_1_K*ENC_1_CONV_RELU_1_INPUT_FEATURES*ENC_1_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &enc_1_conv_relu_1_w[j]);
    }
    for (int j = 0; j < ENC_2_CONV_RELU_0_K*ENC_2_CONV_RELU_0_INPUT_FEATURES*ENC_2_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &enc_2_conv_relu_0_w[j]);
    }
    for (int j = 0; j < ENC_2_CONV_RELU_1_K*ENC_2_CONV_RELU_1_INPUT_FEATURES*ENC_2_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &enc_2_conv_relu_1_w[j]);
    }
    for (int j = 0; j < ENC_3_CONV_RELU_0_K*ENC_3_CONV_RELU_0_INPUT_FEATURES*ENC_3_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &enc_3_conv_relu_0_w[j]);
    }
    for (int j = 0; j < ENC_3_CONV_RELU_1_K*ENC_3_CONV_RELU_1_INPUT_FEATURES*ENC_3_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &enc_3_conv_relu_1_w[j]);
    }
    for (int j = 0; j < CENTRAL_CONV_RELU_0_K*CENTRAL_CONV_RELU_0_INPUT_FEATURES*CENTRAL_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &central_conv_relu_0_w[j]);
    }
    for (int j = 0; j < CENTRAL_CONV_RELU_1_K*CENTRAL_CONV_RELU_1_INPUT_FEATURES*CENTRAL_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &central_conv_relu_1_w[j]);
    }
    for (int j = 0; j < DEC_0_UP_CONV_RELU_K*DEC_0_UP_CONV_RELU_INPUT_FEATURES*DEC_0_UP_CONV_RELU_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_0_up_conv_relu_w[j]);
    }
    for (int j = 0; j < DEC_0_CONV_RELU_0_K*DEC_0_CONV_RELU_0_INPUT_FEATURES*DEC_0_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_0_conv_relu_0_w[j]);
    }
    for (int j = 0; j < DEC_0_CONV_RELU_1_K*DEC_0_CONV_RELU_1_INPUT_FEATURES*DEC_0_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_0_conv_relu_1_w[j]);
    }
    for (int j = 0; j < DEC_1_UP_CONV_RELU_K*DEC_1_UP_CONV_RELU_INPUT_FEATURES*DEC_1_UP_CONV_RELU_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_1_up_conv_relu_w[j]);
    }
    for (int j = 0; j < DEC_1_CONV_RELU_0_K*DEC_1_CONV_RELU_0_INPUT_FEATURES*DEC_1_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_1_conv_relu_0_w[j]);
    }
    for (int j = 0; j < DEC_1_CONV_RELU_1_K*DEC_1_CONV_RELU_1_INPUT_FEATURES*DEC_1_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_1_conv_relu_1_w[j]);
    }
    for (int j = 0; j < DEC_2_UP_CONV_RELU_K*DEC_2_UP_CONV_RELU_INPUT_FEATURES*DEC_2_UP_CONV_RELU_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_2_up_conv_relu_w[j]);
    }
    for (int j = 0; j < DEC_2_CONV_RELU_0_K*DEC_2_CONV_RELU_0_INPUT_FEATURES*DEC_2_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_2_conv_relu_0_w[j]);
    }
    for (int j = 0; j < DEC_2_CONV_RELU_1_K*DEC_2_CONV_RELU_1_INPUT_FEATURES*DEC_2_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_2_conv_relu_1_w[j]);
    }
    for (int j = 0; j < DEC_3_UP_CONV_RELU_K*DEC_3_UP_CONV_RELU_INPUT_FEATURES*DEC_3_UP_CONV_RELU_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_3_up_conv_relu_w[j]);
    }
    for (int j = 0; j < DEC_3_CONV_RELU_0_K*DEC_3_CONV_RELU_0_INPUT_FEATURES*DEC_3_CONV_RELU_0_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_3_conv_relu_0_w[j]);
    }
    for (int j = 0; j < DEC_3_CONV_RELU_1_K*DEC_3_CONV_RELU_1_INPUT_FEATURES*DEC_3_CONV_RELU_1_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &dec_3_conv_relu_1_w[j]);
    }
    for (int j = 0; j < FINAL_CONV_K*FINAL_CONV_INPUT_FEATURES*FINAL_CONV_OUTPUT_FEATURES; j++) {
        fscanf(weights, "%f", &final_conv_w[j]);
    }
	for (int j = 0; j < N*N_STATES; j++) {
			fscanf(input, "%f", &x[j]);
    }

    clock_t time = clock();

    Segmenter(x,
               enc_0_conv_relu_0_w,enc_0_conv_relu_1_w,enc_1_conv_relu_0_w,
               enc_1_conv_relu_1_w,enc_2_conv_relu_0_w,enc_2_conv_relu_1_w,
               enc_3_conv_relu_0_w,enc_3_conv_relu_1_w,central_conv_relu_0_w,
               central_conv_relu_1_w,dec_0_up_conv_relu_w,dec_0_conv_relu_0_w,
               dec_0_conv_relu_1_w,dec_1_up_conv_relu_w,dec_1_conv_relu_0_w,
               dec_1_conv_relu_1_w,dec_2_up_conv_relu_w,dec_2_conv_relu_0_w,
               dec_2_conv_relu_1_w,dec_3_up_conv_relu_w,dec_3_conv_relu_0_w,
               dec_3_conv_relu_1_w,final_conv_w,y, output);

    time = clock()-time;
	printf("\nElapsed computation time: %.5f seconds\n", ((double)time) / CLOCKS_PER_SEC);

    free(enc_0_conv_relu_0_w);
    free(enc_0_conv_relu_1_w);
    free(x);
    free(enc_1_conv_relu_0_w);
    free(enc_1_conv_relu_1_w);
    free(enc_2_conv_relu_0_w);
    free(enc_2_conv_relu_1_w);
    free(enc_3_conv_relu_0_w);
    free(enc_3_conv_relu_1_w);
    free(central_conv_relu_0_w);
    free(central_conv_relu_1_w);
    free(dec_0_up_conv_relu_w);
    free(dec_0_conv_relu_0_w);
    free(dec_0_conv_relu_1_w);
    free(dec_1_up_conv_relu_w);
    free(dec_1_conv_relu_0_w);
    free(dec_1_conv_relu_1_w);
    free(dec_2_up_conv_relu_w);
    free(dec_2_conv_relu_0_w);
    free(dec_2_conv_relu_1_w);
    free(dec_3_up_conv_relu_w);
    free(dec_3_conv_relu_0_w);
    free(dec_3_conv_relu_1_w);
    free(final_conv_w);
    free(y);

    fclose(weights);
    fclose(input);
    fclose(output);
}